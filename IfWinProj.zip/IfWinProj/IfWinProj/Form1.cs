﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IfWinProj
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void textBoxInput_TextChanged(object sender, EventArgs e)
		{

		}

		private void buttonPlay_Click(object sender, EventArgs e)
		{
			int number;
			if (!int.TryParse(textBoxInput.Text, out number))
			{
				labelResult.Text = "Unknown selection!";
			}

			else {
				if (number == 1)
				{
					labelResult.Text = "You won a new boat!";
				}
				else if (number == 2)
				{
					labelResult.Text = "You won 1000€!";
				}
				else if (number == 3)
				{
					labelResult.Text = "You won a new house!";
				}
				else
				{
					labelResult.Text = "Unknown selection!";
				}
				}
			}
		}
	}
